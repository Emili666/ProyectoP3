package co.edu.uniquindio.poo.exceptions;

public class inicioFallidoException  extends Exception{
    public inicioFallidoException(String string) {
        super(string);
    }

}
