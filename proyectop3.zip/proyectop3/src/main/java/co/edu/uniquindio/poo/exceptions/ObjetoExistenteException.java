package co.edu.uniquindio.poo.exceptions;

public class ObjetoExistenteException extends Exception{

    public ObjetoExistenteException(String string) {
        super(string);
    }

}
