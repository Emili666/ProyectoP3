package co.edu.uniquindio.poo.exceptions;

public class ClienteNoEncontradoException extends Exception {
    public ClienteNoEncontradoException(String string) {
        super(string);
    }


}
