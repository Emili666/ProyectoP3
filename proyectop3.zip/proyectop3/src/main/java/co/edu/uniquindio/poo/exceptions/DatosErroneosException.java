package co.edu.uniquindio.poo.exceptions;

public class DatosErroneosException extends Exception {
    public DatosErroneosException(String string) {
        super(string);
    }

    
}
