package co.edu.uniquindio.poo.exceptions;

public class CuentaNoEncontradaException extends Exception {
    public CuentaNoEncontradaException(String string) {
        super(string);
    }
}