package co.edu.uniquindio.poo.exceptions;

public class SaldoInsuficienteException extends Exception {
    public SaldoInsuficienteException(String string) {
        super(string);
    }
}