package co.edu.uniquindio.poo.exceptions;

public class TransaccionInvalidaException extends Exception {
    public TransaccionInvalidaException(String string) {
        super(string);
    }
}
