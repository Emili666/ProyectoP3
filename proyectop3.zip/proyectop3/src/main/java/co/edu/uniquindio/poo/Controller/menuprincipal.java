package co.edu.uniquindio.poo.Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class menuprincipal {

    @FXML
    private Button ADMINBT;

    @FXML
    private Button CCLIENTEBT;

    @FXML
    void adminmenuaction(ActionEvent event) {


    }

    @FXML
    void clientemenuaction(ActionEvent event) {
        

    }

}
