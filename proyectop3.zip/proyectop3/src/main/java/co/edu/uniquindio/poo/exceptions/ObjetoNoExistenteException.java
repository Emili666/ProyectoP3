package co.edu.uniquindio.poo.exceptions;

public class ObjetoNoExistenteException extends Exception{

    public ObjetoNoExistenteException(String string) {
        super(string);
    }

}
