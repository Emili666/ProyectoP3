package co.edu.uniquindio.poo.exceptions;

public class PresupuestoNoEncontradoException extends Exception {
    public PresupuestoNoEncontradoException(String string) {
        super(string);
    }
}